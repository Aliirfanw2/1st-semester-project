//#include<iostream>
//using namespace std;
//void dec(int* arr1, int size)
//{
//	int size1 = 0, num = 0;
//	int* arr2 = new int[size1];
//	for (int i = 0; i < size; i++)
//	{
//
//		num = arr1[i];
//		while (num >= 1)
//		{
//			arr2[size1++] = num;
//			num--;
//		}
//	}
//	cout << "NEw array :";
//	for (int i = 0; i < size1; i++)
//	{
//		cout << arr2[i] << " ";
//	}
//
//
//}
//
//int main()
//{
//	int size = 0, size1 = 0, * ptr = 0, * ptr1 = 0;
//	cout << "ENter the size of orignsl array" << endl;
//	cin >> size;
//	int* arr1 = new int[size];
//	cout << "ENter the value of orignal array" << endl;
//	for (int i = 0; i < size; i++)
//	{
//		cin >> arr1[i];
//	}
//	cout << "Given array :";
//	for (int i = 0; i < size; i++)
//	{
//		cout<<arr1[i]<<" ";
//
//	}
//	dec(arr1, size);
//
//
//
//	delete[] arr1;
//
//
//
//
//
//
//	system("pause");
//	return 0;
//}