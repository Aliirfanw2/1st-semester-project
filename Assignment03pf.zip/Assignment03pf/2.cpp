    //#include<iostream>
    //#include <fstream>
    //using namespace std;
    //int* regrow(int* arr1, int size) {
    //    int* arr2 = new int[size + 1];
    //    for (int i = 0; i < size; i++) {
    //        arr2[i] = arr1[i];
    //    }
    //    delete[] arr1;
    //    return arr2;
    //}
    //int main()
    //{
    //    int size = 15, num, i = 0;
    //    int* arr1 = new int[size];
    //    ifstream ali("data.txt");
    //    if (ali.is_open())
    //    {
    //        cout << "ORignal ARray=";
    //        while (ali >> num)
    //        {
    //            arr1[i] = num;
    //            cout << arr1[i] << " ";
    //            i++;
    //        }

    //        int* uniq = new int[size];
    //        int* freq = new int[size];
    //        int size1 = 0;

    //        for (int i = 0; i < size; i++) 
    //        {
    //            bool uni = true;
    //            for (int j = 0; j < size1; j++) 
    //            {
    //                if (arr1[i] == uniq[j]) 
    //                {
    //                    freq[j]++;
    //                    uni = false;
    //                    break;
    //                }
    //            }
    //            if (uniq) {
    //                uniq[size1] = arr1[i];
    //                freq[size1] = 1;
    //                size1++;
    //            }
    //        }
    //        cout << endl;
    //        cout << "uInqe Array=";
    //        for (int i = 0; i < size1; i++) 
    //        {
    //            cout << uniq[i] << " ";
    //        }
    //        cout << endl;
    //        cout << "FRequency=";
    //        for (int i = 0; i < size1; i++)
    //        {
    //            cout << freq[i] << " ";
    //        }
    //        cout << endl;
    //        cout << endl;
    //        for (int i = 0; i < size1; i++)
    //        {
    //            cout << "uniqe array=" << uniq[i] << " " << "Frequency: " << freq[i] << endl;
    //        }

    //        delete[] arr1;
    //        delete[] uniq;
    //        delete[] freq;
    //    }

    //    system("psuse");
    //    return 0;
    //}