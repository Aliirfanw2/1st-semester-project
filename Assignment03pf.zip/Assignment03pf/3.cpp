//#include<iostream>
//#include<fstream>
//using namespace std;
//int* regrow(int* ar, int num, int& size) {
//	size++;
//	int* n = new int[size];
//	for (int i = 0; i < size - 1; i++) {
//		n[i] = ar[i];
//	}
//	n[size - 1] = num;
//
//	delete[] ar;
//	return n;
//
//}
//int* change(int* ar, int num, int& size, int num2) {
//	int store;
//	int* n = new int[size];
//	bool con = false;
//
//	for (int i = 0; i < size - 1; i++) {
//		if (ar[i] == num || con == true) {
//			n[i] = ar[i + 1];
//			con = true;
//		}
//		else {
//			n[i] = ar[i];
//		}
//	}
//	n[size - 1] = num2;
//
//	delete[] ar;
//	return n;
//
//}
//int* shrink(int* ar, int& size, int num) {
//
//	bool con = false;
//	int* n = new int[size - 1];
//	for (int i = 0; i < size - 1; i++) {
//		if (ar[i] == num || con == true) {
//			n[i] = ar[i + 1];
//
//			con = true;
//		}
//		else {
//			n[i] = ar[i];
//
//		}
//	}
//
//	size--;
//	delete[] ar;
//	return n;
//
//}
//int main() {
//	int num, isize = 0, osize = 0;
//	int* in = new int[isize];
//	int* out = new int[isize];
//	{	ifstream inop("in_id.txt");
//	if (inop.is_open()) {
//		while (inop >> num) {
//			in = regrow(in, num, isize);
//
//
//		}
//	}
//	else {
//		cout << "in file not open for reading \n";
//	}
//	inop.close();
//	}//data get from in_id file.
//	cout << "IN IDS= ";
//	for (int i = 0; i < isize; i++) {
//		cout << "  " << in[i];
//	}
//	{	ifstream inop("out_id.txt");
//	if (inop.is_open()) {
//		while (inop >> num) {
//			out = regrow(out, num, osize);
//
//
//		}
//	}
//	else {
//		cout << "out file not open for reading \n";
//	}
//	inop.close();
//	}//data get from out_id file.
//	cout << "\nOUT ID =";
//	for (int i = 0; i < osize; i++) {
//		cout << " " << out[i];
//	}
//
//	cout << "\nENTER THE NUMBER YOU WANT TO SEND OUT/delete = ";
//
//	while (cin) {
//		cin >> num;
//		cout << "\nto exit press -1";
//		for (int i = 0; i < isize; i++) {
//			if (num == in[i]) {
//
//				in = change(in, num, isize, out[0]);
//				out = shrink(out, osize, out[0]);
//
//				for (int j = i + 1; j < isize; j++) {
//					if (in[j] == num) {
//						in = shrink(in, isize, in[j]);
//
//					}
//
//				}
//
//			}
//
//		}
//		cout << "\nIN IDS= ";
//		for (int i = 0; i < isize; i++) {
//			cout << " " << in[i];
//		}
//		cout << "\nOUT ID =";
//		for (int i = 0; i < osize; i++) {
//			cout << "  " << out[i];
//		}
//		if (num == -1) {
//			break;
//		}
//
//
//	}
//
//
//
//	delete[] in; delete[] out;
//	return 0;
//
//}