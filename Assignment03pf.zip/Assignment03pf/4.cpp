 #include <iostream>
 #include <fstream>
 using namespace std;

 void trans(int arr[][7], int row, int column)
 {
        int temp = row;
        row = column;
        column = temp;
        cout << "Transposed Matrix :";
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < column; j++)
            {
                cout << arr[j][i] << " ";
            }
            cout << endl;
        }
 }

 int main()
 {
        ifstream op;
        op.open("input.txt");
        if (op.is_open())
        {
            const int row = 5;
            const int column = 7;
            int arr1[row][column];
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    op >> arr1[i][j];
                }
            }
            cout << "Original Matrix : ";
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    cout << arr1[i][j] << " ";
                }
                cout << endl;
            }
            cout << "\n" << endl;
        
            trans (arr1, row, column);
        }

        system("pause");
        return 0;
 }
