#include <iostream>
using namespace std;
int main0()
{
    char Array[] = {'H','E','L','L','O','\0'};
    int size = sizeof(Array) / sizeof(char);
 
    for(int i = 0; i < size; i++)
    {
        cout<<Array[i];
    }
 
    return 0;
}
