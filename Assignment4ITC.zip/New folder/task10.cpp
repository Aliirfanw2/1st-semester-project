#include <iostream>
using namespace std;
int main()
	{
		string source[100],destination[100];
		int size;
		cout << " Enter the size of array"<< endl;
		cin  >> size;
		cout << "Enter the string value "<< endl;
		for(int i=size-1;	i>0;	i--)
			{
				cin >> source[i];
			}
		for(int i=0;	i<size;	i++)
			{
				destination[i]=source[i];
			}
		cout << "The destination reverse value is =";
		for (int i=0;	i<size;	i++)
			{
				cout << destination[i]<<" ";
			}
		
		
		
		
		
		
		return 0;
	}
