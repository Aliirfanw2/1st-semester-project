#include<iostream>
using namespace std;
int main1()
	{
		
		char array[]={'H','E','L','L','o','\0'};
		int size =sizeof (array)/sizeof(char);
		for (int i=size;	i>=0;	i--)
			{
				
				cout << array[i];
			}
		
		return 0;
	}
