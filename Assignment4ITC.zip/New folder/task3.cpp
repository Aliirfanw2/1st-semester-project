#include <iostream>
using namespace std;
int main2()
	{
		
		int i=0,find=0;
	    char ali[100];
		cout << "ENTER THE CHARACTER WHO WANT TO FIND THE LENGTH =";
		cin.get (ali, 100);
		while ( ali[i]!=0)
		{
			find++;
			i++;
		}
			cout <<"THESE CHARACTER ARE LENGTH IS ="<< find<< endl;
		
		return 0;
	}
