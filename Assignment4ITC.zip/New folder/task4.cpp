#include <iostream>
using namespace std;
int main3() 
	{
    	char ali[] = {'A','B','C','D','E','F','G','\0'};
    	for (int i = 0; i < 7; i++)
		 {
       	 	if (i % 2 == 0) 
			{
            cout << ali[i] << " ";
       	 	}
    	}
    return 0;
	}

