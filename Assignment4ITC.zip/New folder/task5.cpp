#include<iostream>
using namespace std;
int main4()
	{
		int a=0,b=0;
		char ali [100];
		cout << "enter the number "<< endl;
		cin.get(ali,100);
			cout << "the vowels letters are: "<<endl;
		while(ali[a]!= '\0')
		{
			if (ali[a]=='A' || ali[a]=='E' ||ali[a]=='I' ||ali[a]=='O' ||ali[a]=='U' ||ali[a]=='a' ||ali[a]=='e' ||ali[a]=='i'||ali[a]=='o'||ali[a]=='u')
			{
				
			cout<< ali[a] <<" ";
			}
			b++;
			a++;
		}
		
		
		
		
		
		
		
		
		
		
		
		
	  return 0;
	}
