#include<iostream>
using namespace std;
int main6()
	{
		
	char array[100];
	int lower=0,uper=0;
	cout <<" ENTER THE STRING NUMBER="<< endl;
	cin.get(	array,	100);
		for(int i	=	0; array[i]!='\0';	i++)
		{
			if (array[i]>='a'	&&	array[i] <='z')
			{
				lower++;
			}
			else if (array[i]	>=	'A'	&& array[i]	<='Z')
			{
				uper++;
			}
		}
	      		cout << "THE LOWER LATTER ="<<lower<< endl; 
	     		cout << "THE UPER LATTER =" << uper<< endl;
		
		
		return 0;
	}
