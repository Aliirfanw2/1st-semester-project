#include<iostream>
using namespace std;
int main7()
	{
		string source[100],destination[100];
		int size;
		cout << "Enter the size of array"<<endl;
		cin >>  size;
		cout << "Enter the string of array="<< endl;
		for (int i=0;	i<size;	i++)
			{
				cin >>source [i]; 
			}
		for(int i=0;	i<size;	i++)
			{
				destination[i]=source[i];
			}
				cout <<" The destination value is =";
		for(int i=0;	i<size;	i++)
			{
				cout << destination[i]<<" ";	
			}
	
	
		
		return 0;
	}
