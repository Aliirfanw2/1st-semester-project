#include <iostream>
using namespace std;
int main2()
{
	float sum=0,avrage=0;
	int alone [10] ={23,45,67,78,3,567,0,-1,4,67};
	for(int i=0;i<10;i++)
		{   
		 {
		 	   if (alone[i]%2==0)
		    sum +=alone[i];
		    avrage=sum/3;
		 }
		}
	        cout << "THE SUM OF NUMBER IS ="<< sum<< endl;
	        cout << "THE OF NUMBER IS ="<< avrage<< endl;
	
	return 0;
	
}
