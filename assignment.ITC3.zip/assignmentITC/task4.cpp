#include<iostream>
using namespace std;

int main3()
{  
    int size =10;
    int array[10]={2,4,5,66,75,8,53,11,3,45};
    int search,time;
    cout <<"enter the number="<<endl;
    cin >> search;
    for (int i=0;i<10;i++)
    {
        if (search==array[i])
       {
       cout<<"these are index number="<<i<<endl;
        break;
    }
    if (i==9 && search!=array[i])
    {
      cout <<"these number are not present"<<endl;
    }
    
    
    }
     return 0;

}
