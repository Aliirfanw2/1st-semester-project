#include <iostream>
using namespace std ;
int main ()
	{
		
		int size=10;
		int alone[10]={ 2,4,5,66,75,8,53,11,3,45};
		int search, store,i=2;
		int first=0,last=9,second=9,middle=(first+second)/2;
		
		for (int i=0;i<=(size-1);i++)
			{
				for (int j=0; j<size;j++)
				{
					if(alone[i]<alone[j])
					{
						store=alone[i];
				    alone[i]=alone[j];
				     alone[j]=store;
					}
				
				}
				
			}
			for(int k=0;k<size;k++)
				
				{
					cout << alone[k]<<" ";
				}
		cout << "ENTER THE NUMBER WHO WANT TO SEARCH ="<< endl;
		cin >> search;
	
		 while (last>=first)
		 {
			if (search<alone[middle])
			 {
			 	 last=middle-1;
			 }
			else if (search>alone [middle])
			{
					first=middle+1;
		     }
	
			else if (search=alone [middle])
			{
				cout << "THE NUMBER IS EXICT in index="<< middle;
				break;
			}
			
			middle =(first+last)/2;
			if(first>last)
			{
				cout << "THE NUMBER DOES NOT EXICT"<<endl;
			}
	   
	   }
			
	
		
		
		
		
		
		
		
		
		return 0;
		
	}
