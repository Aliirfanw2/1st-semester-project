	//#include<iostream>
	//#include<fstream>
	//using namespace std;

	//int main1()
	//{
	//	 ifstream Ali;
	//	 Ali.open("deta.txt");
	//		 if (Ali.is_open())
	//		 {
	//			 int a=0, count1 = 0, count2 = 0;
	//			 int read=0;
	//			 // Read  first single intiger;
	//			 Ali >> read;
	//			 for (int i = 0; i < read; i++)
	//			 {
	//				 Ali >> a;
	//				 cout << a <<" ";
	//				 count1++;
	//			 }
	//			 cout << endl;
	//			 count1 = count1 + 1;
	//			 // Read   After first  intiger record;
	//			 Ali>>read;
	//			for (int i = 0 ; i < read; i++)
	//			 {
	//				Ali >>a;
	//				cout << a << " ";
	//				count1++;
	//			 }
	//			cout << endl;
	//			count1 = count1 + 1;
	//			// Read  after second  intiger record;
	//			Ali >> read;
	//			for (int i = 0; i < read; i++)
	//			{
	//				Ali >> a;
	//				cout << a << " ";
	//				count1++;
	//			}
	//			cout << endl;
	//			count1 = count1 + 1;
	//			// Read  after second  intiger record;
	//			Ali >> read;
	//			for (int i = 0; i < read; i++)
	//			{
	//				Ali >> a;
	//				cout << a << " ";
	//				count1++;
	//			}
	//			cout << endl;
	//		 }
	//		 else
	//		 {
	//			 cout << "File does not open" << endl;
	//		 }
	//		 Ali.close();











	//	system("pause");
	//	return 0;
	//}