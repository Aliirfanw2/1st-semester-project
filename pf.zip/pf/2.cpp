	//#include<iostream>
	//#include<fstream>
	//using namespace std;

	//int main2()
	//{
	//	ifstream Ali;
	//	Ali.open("deta.txt");
	//	if (Ali.is_open())
	//	{
	//		int a = 0, count1 = 0, b, c, d;
	//		int read = 0,row1=0,row2=0,row3=0,row4=0;
	//		cout << "Enter three number first Row second number entery number oR third replace" << endl;
	//		cin >> b >> c >> d;
	//		Ali >> read;
	//	
	//		for (int i = 0; i < read; i++)
	//		{
	//			Ali >> a;
	//		
	//				row1 = 1;
	//				if (row1 == b && a == c)
	//				{
	//					a = d;
	//				}
	//				cout << a << " " ;
	//				count1++;
	//		}
	//	
	//		cout << endl;
	//		count1 = count1 + 1;
	//		Ali >> read;
	//		for (int i = 0; i < read; i++)
	//		{
	//			Ali >> a;
	//			row2 = 2;
	//			cout << a << " ";
	//			count1++;
	//		}
	//		cout << endl;
	//		count1 = count1 + 1;
	//		Ali >> read;
	//		for (int i = 0; i < read; i++)
	//		{
	//			Ali >> a;
	//			row3 = 3;
	//			cout << a << " ";
	//			count1++;
	//		}
	//		cout << endl;
	//		count1 = count1 + 1;
	//		Ali >> read;
	//		for (int i = 0; i < read; i++)
	//		{
	//			Ali >> a;
	//			row4 = 4;
	//			cout << a << " ";
	//			count1++;
	//		}
	//		cout << endl;
	//	
	//	}
	//	else
	//	{
	//		cout << "File does not open" << endl;
	//	}

	//	Ali.close();











	//	system("pause");
	//	return 0;
	//}