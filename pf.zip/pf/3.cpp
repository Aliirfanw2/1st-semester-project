#include<iostream>
#include<fstream>
using namespace std;
void print(char*, int&);
void print(char a[], int& size) {
	int i = 0;
	char ch;
	ifstream read("input.txt");
	if (read.is_open())
	{
		while (read.get(ch)) 
		{

			a[i] = ch;
			i++;
		}a[i - 1] = '\0';
	}
	else
	{
		cout << "File not opened" << endl;
	}
	read.close();
	size = i - 1;
}

int main3()
{
	const int size = 100;
	int i = 0, first = 0, second = 1, last = 0;
	bool prime = true;
	char arr[size];
	print(arr, first);
	cout << arr << endl;
	while (arr[i] != '\0' && (i < first)) {
		prime = true;

		last = i;

		while (arr[i] != ' ' && (i < first)) {
			second++;
			i++;
		}
		second = second - 1;

		for (int p = 2; p <= second / 2; p++) 
		{
			if (second % p == 0) {
				prime = false;
				break;
			}
		}
		if (prime == true)
		{
			for (int o = last; o <= i; o++) {

				if (arr[o] != '\0')
				{
					arr[o] = '0';
				}
			}

		}
		i++;
		second = 1;
	}
	i = 0;
	while (arr[i] != '\0')
	{
		second = i;
		while (arr[i] == '0') {
			while (i < first) {
				arr[i] = arr[i + 1];
				i++;
			}
			i = second;
		}
		i = second;
		i++;

	}
	cout << "Modified: "<< arr;
	return 0;
}