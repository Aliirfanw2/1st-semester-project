	#include<iostream>
	#include<fstream>
	using namespace std;
	void print(char*, int);
	int main() {
		const int size = 100;
		char arr[size], pat[5], rpat[5], count2 = 1;
		int i = 0;
		bool end = true;
		print(arr, size);
		cout << arr;
		cout << "enter pat";
		cin >> pat;
		cout << "enter rpat";
		cin >> rpat;

		cout << pat << endl;
		cout << rpat;
		while (arr[i] != '\0') {
			end = true;
			count2 = 1;
			for (int p = 0; p < pat[p] < 3; p++)
			{
				if (arr[i] == pat[p])
				{
					int o = p;
					while (pat[o + count2] != '\0' && o + count2 < strlen(pat))
					{
						if (pat[o + count2] != arr[i + count2])
						{
							end = false;
							break;
						}
						count2++;
					}
					if (end == true) {
						for (int c = i; c < (i + count2); c++) {
							arr[c] = 0;

						}

					}
				}
			}
			cout << "" << arr << endl;
			if (end == false) {
				i = i + count2;
			}
			else {
				i++;
			}
		}
		cout << arr;
		return 0;
	}
	void print(char a[], int size) {
		ifstream read("text.txt");
		if (read.is_open()) {
			read.getline(a, size);
		}
		else { cout << " file not opened"; }
		read.close();
	}