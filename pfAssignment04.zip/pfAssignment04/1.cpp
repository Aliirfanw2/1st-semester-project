#include<iostream>
#include<fstream>
using namespace std;

int**print(int** arr,int row,int column)
{
	row = 5;
	column = 7;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < 7;j++)
		{
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
	return arr;
}

int main1()
{
	int** arr1 = NULL;
	int row = 5, column = 7;
	arr1 = new int*[row];
	for (int i = 0; i < row; i++)
	{
		arr1[i] = new int [column];
	}
	arr1[row][column];
	ifstream read;
	read.open("input.txt");
	if (read.is_open())
	{
		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < column; j++)
			{
				read >> arr1[i][j];
			}
		}
		print(arr1, row, column);
	}
	else
	{
		cout << "FIle does Not open" << endl;
	}
	for (int i = 0; i < row; i++)
	{
		delete[] arr1[i];
	}
	delete[] arr1;



	system("pause");
	return 0;
}





