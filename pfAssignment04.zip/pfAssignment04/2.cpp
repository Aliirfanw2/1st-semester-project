	#include<iostream>
	#include<fstream>
	using namespace std;

	const int row = 5;
	const int column = 7;

	void swapR(int arr[][column], int row1, int row2) {
		for (int j = 0; j < column; j++) {
			int temp = arr[row1][j];
			arr[row1][j] = arr[row2][j];
			arr[row2][j] = temp;
		}
	}

	void print(int arr[][column]) {
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < column; j++) {
				cout << arr[i][j] << " ";
			}
			cout << endl;
		}
	}


	int main2()
	{
		int arr[row][column];

		ifstream read;
		read.open("input.txt");
		if (read.is_open())
		{
			for (int i = 0; i < row; i++)
			{
			for (int j = 0; j < column; j++)
				{
					read >> arr[i][j];
				}
			}
		}
		else
		{
			cout << "File Does not open" << endl;
		}

		cout << "Array before swapping:" << endl;
		print(arr);

		int row1, row2;
		cout << "Enter the two rows you want to swap (0-4): ";
		cin >> row1 >> row2;

		if (row1 < 0 || row1 >= row || row2 < 0 || row2 >= row) {
			cout << "Invalid row numbers." << endl;
			return 1;
		}

		swapR(arr, row1, row2);

		cout << "Array after swapping:" << endl;
		print(arr);


		system("pause");
		return 0;
	}





