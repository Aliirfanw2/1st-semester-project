#include<iostream>
#include<fstream>
using namespace std;

const int row = 5;
const int column = 7;
void swapColumns(int arr[][column], int col1, int col2) {
	for (int i = 0; i < row; i++) {
		int temp = arr[i][col1];
		arr[i][col1] = arr[i][col2];
		arr[i][col2] = temp;
	}
}

void printArray3(int arr[][column]) {
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < column; j++) {
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
}

int main3()
{
	int arr[row][column];

	ifstream read;
	read.open("input.txt");
	if (read.is_open())
	{
		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < column; j++)
			{
				read >> arr[i][j];
			}
		}
	}
	else
	{
		cout << "File Does not open" << endl;
	}

	cout << "Array before swapping:" << endl;
	printArray3(arr);

	int col1, col2;
	cout << "Enter the two columns you want to swap (0-6): ";
	cin >> col1 >> col2;

	if (col1 < 0 || col1 >= column || col2 < 0 || col2 >= column) {
		cout << "Invalid column numbers." << endl;
		return 1;
	}

	swapColumns(arr, col1, col2);

	cout << "Array after swapping:" << endl;
	printArray3(arr);


	system("pause");
	return 0;
}





