#include<iostream>
#include<fstream>
using namespace std;

const int row = 5;
const int column = 7;

void ctranspose(const int arr[][column], int transpose[][row]) {
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < column; j++) {
			transpose[j][i] = arr[i][j];
		}
	}
}

void print(const int arr[][column]) {
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < column; j++) {
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
}

int main()
{
	int arr[row][column];
	int transpose[column][row];

	ifstream read;
	read.open("input.txt");
	if (read.is_open())
	{
		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < column; j++)
			{
				read >> arr[i][j];
			}
		}
	}
	else
	{
		cout << "File Does not open" << endl;
	}

	cout << "Original Array:" << endl;
	print(arr);
	//transpose function call
	ctranspose(arr, transpose);

	cout << "Transpose Array:" << endl;
	//print function call
	print( arr);


	system("pause");
	return 0;
}





