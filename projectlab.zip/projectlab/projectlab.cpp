#include <iostream>
using namespace std;
int main()
{
	const int rnum = 10, mt = 10, fm = 10, cls = 10, grad = 10;
	int temp = 0;
	float store = 0;
	int astore = 0;
	char lab, e, d,bstore=0;
	int a, b, c;
	int rirfan[rnum] = { 2001, 2005, 2002, 2004, 2003 };
	char cirfan[cls] = { '1' , '2', '5', '4', '3' };
	float mirfan[mt] = { 23.2, 22, 34.4, 23, 32 };
	float firfan[fm] = { 50, 60.5, 73.5, 30, 100 };
	int currentIndex = 5;
	char girfan[grad] = { 'A', 'B', 'C', 'D', 'F' };
	bool chek = true,print=true;

	cout << "Enter the operator who want to perform on these recorde\npress R for roll number wise in ascending order\n press r for roll number wise in descending order\n press M ascending order based on marks in Midtermn press \n m to view record in decending order based og mid term marks\n press F to view the record in ascending order based on final term marks\n press f to view the record in decending order based on final term marks\n press G to view the record in ascending order based on GARADE\n press g to view the record in decending order based on GARADE \n press N to add a nw student record in data base\n press D to delete  a students data " << endl;
	cout <<	"The students greater than X marks in final exam in descending order press a \n all the students greater than X marks in final exam in ascending order b \n of all the students less than or equal to X marks in final exam in descending c \n all the students less than or equal to X marks in final exam in ascending order d \n all the students greater than X grade in descending order with respect to grade h \nof all the students greater than X grade in ascending order with respect to grade j \n all the students less than or equal to X grade in descending order with respect to grade k \n all the students less than or equal to X grade in ascending order with respect to grade l"<<endl;
			//press R for roll number wise in ascending order
			//press r for roll number wise in descending order
			//press M ascending order based on marks in Midterm
			//press m to view record in decending order based og mid term marks
			//press F to view the record in ascending order based on final term marks
			//press f to view the record in decending order based on final term marks
			//press G to view the record in ascending order based on GARADE
			//press g to view the record in decending order based on GARADE
			//press N to add a nw student record in data base
			//press D to delete  a students data ;
			//The students greater than X marks in final exam in descending order press a
			//all the students greater than X marks in final exam in ascending order b
			// all the students less than or equal to X marks in final exam in descending c
			//all the students less than or equal to X marks in final exam in ascending order d
			//all the students greater than X grade in descending order with respect to grade h 
			// all the students greater than X grade in ascending order with respect to grade j 
			// all the students less than or equal to X grade in descending order with respect to grade k
			//all the students less than or equal to X grade in ascending order with respect to grade l
	cout << "ROLL NUMBER" << "\t\tMID TERMS MARKS" << "\t\tFINAL MARKS" << "\t\tCLASS" << "\t\tGRADE" << endl;
	for (int i = 0; i < 10; i++)
	{
		print = true;
		cout << rirfan[i] << "\t\t\t" << mirfan[i] << "\t\t\t" << firfan[i] << "\t\t\t" << cirfan[i] << "\t\t";
		if (firfan[i] > 86)
		{
			cout << girfan[0];
		}
		if (firfan[i] >= 73 && firfan[i] <= 85)
		{
			cout << girfan[1];
		}
		else if (firfan[i] >= 60 && firfan[i] <= 72)
		{
			cout << girfan[2];
		}
		else if (firfan[i] >= 50 && firfan[i] <= 60)
		{
			cout << girfan[3];
		}
		else if (firfan[i] < 50)
		{
			cout << girfan[4];

		}
		else if (firfan[i] > 0 && firfan[i] < 49)
		{
			cout << girfan[4];
		}
		cout << endl;
	}
	do {

		cout << "Please enter the choice to perform any action:" << endl;
		cin >> lab;
		if (lab == 'e' || lab == 'E') {
			break;
		}
		switch (lab)
		{
		case 'r':
		{

			for (int i = 0; i < rnum; i++)
			{
				for (int j = i; j < rnum; j++)
				{
					if (rirfan[i] < rirfan[j] && firfan[j] != 0)
					{
						store = rirfan[i];
						rirfan[i] = rirfan[j];
						rirfan[j] = store;
						store = mirfan[i];
						mirfan[i] = mirfan[j];
						mirfan[j] = store;
						store = firfan[i];
						firfan[i] = firfan[j];
						firfan[j] = store;
					}
				}
			}
			break;
		}
		case 'R':
		{

			for (int i = 0; i < rnum; i++)
			{
				for (int j = i; j < rnum; j++)
				{
					if (rirfan[i] > rirfan[j] && firfan[j] != 0)
					{
						store = rirfan[i];
						rirfan[i] = rirfan[j];
						rirfan[j] = store;
						store = mirfan[i];
						mirfan[i] = mirfan[j];
						mirfan[j] = store;
						store = firfan[i];
						firfan[i] = firfan[j];
						firfan[j] = store;
					}
				}
			}
			break;
		}

		case 'M':
		{
			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < i; j++)
				{
					if (mirfan[i] < mirfan[j])
					{
						store = rirfan[i];
						rirfan[i] = rirfan[j];
						rirfan[j] = store;

						store = mirfan[i];
						mirfan[i] = mirfan[j];
						mirfan[j] = store;

						store = firfan[i];
						firfan[i] = firfan[j];
						firfan[j] = store;

						store = cirfan[i];
						cirfan[i] = cirfan[j];
						cirfan[j] = store;

						store = girfan[i];
						girfan[i] = girfan[j];
						girfan[j] = store;

					}
				}
			}
			break;
		}
		case 'm':
		{
			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < i; j++)
				{
					if (mirfan[i] > mirfan[j])
					{
						store = rirfan[i];
						rirfan[i] = rirfan[j];
						rirfan[j] = store;

						store = mirfan[i];
						mirfan[i] = mirfan[j];
						mirfan[j] = store;

						store = firfan[i];
						firfan[i] = firfan[j];
						firfan[j] = store;

						store = cirfan[i];
						cirfan[i] = cirfan[j];
						cirfan[j] = store;

						store = girfan[i];
						girfan[i] = girfan[j];
						girfan[j] = store;

					}
				}
			}
			break;
		}

		case 'F':
		{
			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < i; j++)
				{
					if (firfan[i] < firfan[j])
					{
						store = rirfan[i];
						rirfan[i] = rirfan[j];
						rirfan[j] = store;

						store = mirfan[i];
						mirfan[i] = mirfan[j];
						mirfan[j] = store;

						store = firfan[i];
						firfan[i] = firfan[j];
						firfan[j] = store;

						store = cirfan[i];
						cirfan[i] = cirfan[j];
						cirfan[j] = store;

						store = girfan[i];
						girfan[i] = girfan[j];
						girfan[j] = store;

					}
				}
			}
			break;
		}
		case 'f':
		{
			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < i; j++)
				{
					if (firfan[i] > firfan[j])
					{
						store = rirfan[i];
						rirfan[i] = rirfan[j];
						rirfan[j] = store;

						store = mirfan[i];
						mirfan[i] = mirfan[j];
						mirfan[j] = store;

						store = firfan[i];
						firfan[i] = firfan[j];
						firfan[j] = store;

						store = cirfan[i];
						cirfan[i] = cirfan[j];
						cirfan[j] = store;

						store = girfan[i];
						girfan[i] = girfan[j];
						girfan[j] = store;

					}
				}
			}
			break;
		}
		case 'G':
		{
			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < i; j++)
				{
					if (girfan[i] < girfan[j])
					{
						store = rirfan[i];
						rirfan[i] = rirfan[j];
						rirfan[j] = store;

						store = mirfan[i];
						mirfan[i] = mirfan[j];
						mirfan[j] = store;

						store = firfan[i];
						firfan[i] = firfan[j];
						firfan[j] = store;

						store = cirfan[i];
						cirfan[i] = cirfan[j];
						cirfan[j] = store;

						store = girfan[i];
						girfan[i] = girfan[j];
						girfan[j] = store;

					}
				}
			}
			break;
		}
		case 'g':
		{
			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < i; j++)
				{
					if (girfan[i] > girfan[j])
					{
						store = rirfan[i];
						rirfan[i] = rirfan[j];
						rirfan[j] = store;

						store = mirfan[i];
						mirfan[i] = mirfan[j];
						mirfan[j] = store;

						store = firfan[i];
						firfan[i] = firfan[j];
						firfan[j] = store;

						store = cirfan[i];
						cirfan[i] = cirfan[j];
						cirfan[j] = store;

						store = girfan[i];
						girfan[i] = girfan[j];
						girfan[j] = store;

					}
				}
			}
			break;
		}
		case 'N':
		{
			bool rollNoExist = false;
			do {
				cout << "PLEASE ENTER THE NEW ROLL NUMBER OF NEW STUDENT=" << endl;
				cin >> a;
				rollNoExist = false;
				for (int j = 0; j < currentIndex; j++)
				{
					if (rirfan[j] == a)
					{
						cout << "the roll number is allready exict" << endl;
						rollNoExist = true;
						break;
					}


				}
			} while (rollNoExist == true);

			cout << "PLEASE ENTER THE MID MARKS=" << endl;
			cin >> b;
			cout << "PLEASE ENTER THE FINAL MARKS=" << endl;
			cin >> c;
			cout << "PLEASE ENTER THE CLASS=" << endl;
			cin >> d;
			cout << "PLEASE ENTER THE GRADE=" << endl;
			cin >> e;
			rirfan[currentIndex] = a;
			mirfan[currentIndex] = b;
			firfan[currentIndex] = c;
			cirfan[currentIndex] = d;
			girfan[currentIndex] = e;
			currentIndex++;
			break;
		}

		case 'D':
		
		
		{
			cout << "PLEASE ENTR THE ROLL NUMBER WHO WANT TO DELET=" << endl;
			cin >> a;
			for (int i = 0; i < rnum; i++)
			{
				if (rirfan[i] == a)
				{
					temp = i;
					break;
				}
			}
			rirfan[temp] = 0;
			mirfan[temp] = 0;
			firfan[temp] = 0;
			cirfan[temp] = 0;
			girfan[temp] = 0;
				if (temp < currentIndex)
	    	{
				for (int i = temp; i < currentIndex; i++)
				{
					rirfan[i] = rirfan[i + 1];
					mirfan[i] = mirfan[i + 1];
					firfan[i] = firfan[i + 1];
					cirfan[i] = cirfan[i + 1];
					girfan[i] = girfan[i + 1];
				}
			}
			break;
		}
		case'a': {
			print = false;
			cout << "Enter the marks X number";
			cin >> astore;

			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < i; j++)
				{
					if (firfan[i] > firfan[j])
					{
						store = rirfan[i];
						rirfan[i] = rirfan[j];
						rirfan[j] = store;

						store = mirfan[i];
						mirfan[i] = mirfan[j];
						mirfan[j] = store;

						store = firfan[i];
						firfan[i] = firfan[j];
						firfan[j] = store;

						store = cirfan[i];
						cirfan[i] = cirfan[j];
						cirfan[j] = store;

					}
				}
			}
		 
			cout << "ROLL NUMBER" << "\t\tMID TERMS MARKS" << "\t\tFINAL MARKS" << "\t\tCLASS" << "\t\tGRADE" << endl;
			for (int i = 0; i < 10; i++)
			{
				if (firfan[i]>astore) {
					cout << rirfan[i] << "\t\t\t" << mirfan[i] << "\t\t\t" << firfan[i] << "\t\t\t" << cirfan[i] << "\t\t";
					if (firfan[i] > 86)
				{
					cout << girfan[0];
				}
				if (firfan[i] >= 73 && firfan[i] <= 85)
				{
					cout << girfan[1];
				}
				else if (firfan[i] >= 60 && firfan[i] <= 72)
				{
					cout << girfan[2];
				}
				else if (firfan[i] >= 50 && firfan[i] <= 60)
				{
					cout << girfan[3];
				}
				else if (firfan[i] < 50)
				{
					cout << girfan[4];
				}

				cout << endl;
			}
			}
			break;
		}
	case'b': {
			print = false;
			cout << "Enter the marks X number =";
			cin >> astore;

			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < i; j++)
				{
					if (firfan[i] < firfan[j])
					{
						store = rirfan[i];
						rirfan[i] = rirfan[j];
						rirfan[j] = store;

						store = mirfan[i];
						mirfan[i] = mirfan[j];
						mirfan[j] = store;

						store = firfan[i];
						firfan[i] = firfan[j];
						firfan[j] = store;

						store = cirfan[i];
						cirfan[i] = cirfan[j];
						cirfan[j] = store;

					}
				}
			}
		 
			cout << "ROLL NUMBER" << "\t\tMID TERMS MARKS" << "\t\tFINAL MARKS" << "\t\tCLASS" << "\t\tGRADE" << endl;
			for (int i = 0; i < 10; i++)
			{
				if (firfan[i]>astore) {
					cout << rirfan[i] << "\t\t\t" << mirfan[i] << "\t\t\t" << firfan[i] << "\t\t\t" << cirfan[i] << "\t\t";
					if (firfan[i] > 86)
					{
						cout << girfan[0];
					}
					if (firfan[i] >= 73 && firfan[i] <= 85)
					{
						cout << girfan[1];
					}
					else if (firfan[i] >= 60 && firfan[i] <= 72)
					{
						cout << girfan[2];
					}
					else if (firfan[i] >= 50 && firfan[i] <= 60)
					{
						cout << girfan[3];
					}
					else if (firfan[i] < 50)
					{
						cout << girfan[4];
					}

					cout << endl;
				}
			}
			break;
		}
	case'c': {
			print = false;
			cout << "Enter the marks X number =";
			cin >> astore;

			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < i; j++)
				{
					if (firfan[i] > firfan[j])
					{
						store = rirfan[i];
						rirfan[i] = rirfan[j];
						rirfan[j] = store;

						store = mirfan[i];
						mirfan[i] = mirfan[j];
						mirfan[j] = store;

						store = firfan[i];
						firfan[i] = firfan[j];
						firfan[j] = store;

						store = cirfan[i];
						cirfan[i] = cirfan[j];
						cirfan[j] = store;
					}
				}
			}
		 
			cout << "ROLL NUMBER" << "\t\tMID TERMS MARKS" << "\t\tFINAL MARKS" << "\t\tCLASS" << "\t\tGRADE" << endl;
			for (int i = 0; i < 10; i++)
			{
				if (firfan[i]<=astore) {
					cout << rirfan[i] << "\t\t\t" << mirfan[i] << "\t\t\t" << firfan[i] << "\t\t\t" << cirfan[i] << "\t\t";
					if (firfan[i] > 86)
					{
						cout << girfan[0];
					}
					if (firfan[i] >= 73 && firfan[i] <= 85)
					{
						cout << girfan[1];
					}
					else if (firfan[i] >= 60 && firfan[i] <= 72)
					{
						cout << girfan[2];
					}
					else if (firfan[i] >= 50 && firfan[i] <= 60)
					{
						cout << girfan[3];
					}
					else if (firfan[i] < 50)
					{
						cout << girfan[4];
					}

					cout << endl;
				}
			}
			break;
		}
	case'd': {
			print = false;
			cout << "Enter the marks X number =";
			cin >> astore;

			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < i; j++)
				{
					if (firfan[i] < firfan[j])
					{
						store = rirfan[i];
						rirfan[i] = rirfan[j];
						rirfan[j] = store;

						store = mirfan[i];
						mirfan[i] = mirfan[j];
						mirfan[j] = store;

						store = firfan[i];
						firfan[i] = firfan[j];
						firfan[j] = store;

						store = cirfan[i];
						cirfan[i] = cirfan[j];
						cirfan[j] = store;
					}
				}
			}
		 
			cout << "ROLL NUMBER" << "\t\tMID TERMS MARKS" << "\t\tFINAL MARKS" << "\t\tCLASS" << "\t\tGRADE" << endl;
			for (int i = 0; i < 10; i++)
			{
				if (firfan[i]<=astore) {
					cout << rirfan[i] << "\t\t\t" << mirfan[i] << "\t\t\t" << firfan[i] << "\t\t\t" << cirfan[i] << "\t\t";
					if (firfan[i] > 86)
					{
						cout << girfan[0];
					}
					if (firfan[i] >= 73 && firfan[i] <= 85)
					{
						cout << girfan[1];
					}
					else if (firfan[i] >= 60 && firfan[i] <= 72)
					{
						cout << girfan[2];
					}
					else if (firfan[i] >= 50 && firfan[i] <= 60)
					{
						cout << girfan[3];
					}
					else if (firfan[i] < 50)
					{
						cout << girfan[4];
					}

					cout << endl;
				}
			}
			break;
		}
		case'h': {
			print = false;
			cout << "ENTER THE GRADE X  =";
			cin >> bstore;


			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < i; j++)
				{
					if (firfan[i] < firfan[j])
					{
						store = rirfan[i];
						rirfan[i] = rirfan[j];
						rirfan[j] = store;

						store = mirfan[i];
						mirfan[i] = mirfan[j];
						mirfan[j] = store;

						store = firfan[i];
						firfan[i] = firfan[j];
						firfan[j] = store;

						store = cirfan[i];
						cirfan[i] = cirfan[j];
						cirfan[j] = store;

					}
				}
			}
			if (bstore == 'A') {
				store = 100;
			}
			else if (bstore == 'B') {
				store = 85;
			}
			else 	if (bstore == 'C') {
				store = 72;
			}

			else if (bstore == 'D') {
				store = 60;
			}
			else 	if (bstore == 'F') {
				store = 50;
			}

			cout << "ROLL NUMBER" << "\t\tMID TERMS MARKS" << "\t\tFINAL MARKS" << "\t\tCLASS" << "\t\tGRADE" << endl;
			for (int i = 0; i < 10; i++)
			{
				if (firfan[i] > store) {


					cout << rirfan[i] << "\t\t\t" << mirfan[i] << "\t\t\t" << firfan[i] << "\t\t\t" << cirfan[i] << "\t\t";
					if (firfan[i] > 86)
					{
						cout << girfan[0];
					}
					if (firfan[i] >= 73 && firfan[i] <= 85)
					{
						cout << girfan[1];
					}
					else if (firfan[i] >= 60 && firfan[i] <= 72)
					{
						cout << girfan[2];
					}
					else if (firfan[i] >= 50 && firfan[i] <= 60)
					{
						cout << girfan[3];
					}
					else if (firfan[i] < 50)
					{
						cout << girfan[4];
					}

					cout << endl;
				}
			}
			break;
		}
	case'j': {
			print = false;
			cout << "ENTER THE GRADE X  =";
			cin >> bstore;


			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < i; j++)
				{
					if (firfan[i] > firfan[j])
					{
						store = rirfan[i];
						rirfan[i] = rirfan[j];
						rirfan[j] = store;

						store = mirfan[i];
						mirfan[i] = mirfan[j];
						mirfan[j] = store;

						store = firfan[i];
						firfan[i] = firfan[j];
						firfan[j] = store;

						store = cirfan[i];
						cirfan[i] = cirfan[j];
						cirfan[j] = store;

					}
				}
			}
			if (bstore == 'A') {
				store = 100;
			}
			else if (bstore == 'B') {
				store = 85;
			}
			else 	if (bstore == 'C') {
				store = 72;
			}

			else if (bstore == 'D') {
				store = 60;
			}
			else 	if (bstore == 'F') {
				store = 50;
			}

			cout << "ROLL NUMBER" << "\t\tMID TERMS MARKS" << "\t\tFINAL MARKS" << "\t\tCLASS" << "\t\tGRADE" << endl;
			for (int i = 0; i < 10; i++)
			{
				if (firfan[i] > store) {


					cout << rirfan[i] << "\t\t\t" << mirfan[i] << "\t\t\t" << firfan[i] << "\t\t\t" << cirfan[i] << "\t\t";
					if (firfan[i] > 86)
					{
						cout << girfan[0];
					}
					if (firfan[i] >= 73 && firfan[i] <= 85)
					{
						cout << girfan[1];
					}
					else if (firfan[i] >= 60 && firfan[i] <= 72)
					{
						cout << girfan[2];
					}
					else if (firfan[i] >= 50 && firfan[i] <= 60)
					{
						cout << girfan[3];
					}
					else if (firfan[i] < 50)
					{
						cout << girfan[4];
					}

					cout << endl;
				}
			}
			break;
		}
	case'k': {
			print = false;
			cout << "ENTER THE GRADE X  =";
			cin >> bstore;


			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < i; j++)
				{
					if (firfan[i] < firfan[j])
					{
						store = rirfan[i];
						rirfan[i] = rirfan[j];
						rirfan[j] = store;

						store = mirfan[i];
						mirfan[i] = mirfan[j];
						mirfan[j] = store;

						store = firfan[i];
						firfan[i] = firfan[j];
						firfan[j] = store;

						store = cirfan[i];
						cirfan[i] = cirfan[j];
						cirfan[j] = store;

					}
				}
			}
			if (bstore == 'A') {
				store = 100;
			}
			else if (bstore == 'B') {
				store = 85;
			}
			else 	if (bstore == 'C') {
				store = 72;
			}

			else if (bstore == 'D') {
				store = 60;
			}
			else 	if (bstore == 'F') {
				store = 50;
			}

			cout << "ROLL NUMBER" << "\t\tMID TERMS MARKS" << "\t\tFINAL MARKS" << "\t\tCLASS" << "\t\tGRADE" << endl;
			for (int i = 0; i < 10; i++)
			{
				if (firfan[i] < store) {


					cout << rirfan[i] << "\t\t\t" << mirfan[i] << "\t\t\t" << firfan[i] << "\t\t\t" << cirfan[i] << "\t\t";
					if (firfan[i] > 86)
					{
						cout << girfan[0];
					}
					if (firfan[i] >= 73 && firfan[i] <= 85)
					{
						cout << girfan[1];
					}
					else if (firfan[i] >= 60 && firfan[i] <= 72)
					{
						cout << girfan[2];
					}
					else if (firfan[i] >= 50 && firfan[i] <= 60)
					{
						cout << girfan[3];
					}
					else if (firfan[i] < 50)
					{
						cout << girfan[4];
					}

					cout << endl;
				}
			}
			break;
		}
		case'l': 
		{
			print = false;
			cout << "ENTER THE GRADE X  =";
			cin >> bstore;


			for (int i = 0; i < 5; i++)
			{
				for (int j = 0; j < i; j++)
				{
					if (firfan[i] > firfan[j])
					{
						store = rirfan[i];
						rirfan[i] = rirfan[j];
						rirfan[j] = store;

						store = mirfan[i];
						mirfan[i] = mirfan[j];
						mirfan[j] = store;

						store = firfan[i];
						firfan[i] = firfan[j];
						firfan[j] = store;

						store = cirfan[i];
						cirfan[i] = cirfan[j];
						cirfan[j] = store;

					}
				}
			}
			if (bstore == 'A') {
				store = 100;
			}
			else if (bstore == 'B') {
				store = 85;
			}
			else 	if (bstore == 'C') {
				store = 72;
			}

			else if (bstore == 'D') {
				store = 60;
			}
			else 	if (bstore == 'F') {
				store = 50;
			}

			cout << "ROLL NUMBER" << "\t\tMID TERMS MARKS" << "\t\tFINAL MARKS" << "\t\tCLASS" << "\t\tGRADE" << endl;
			for (int i = 0; i < 10; i++)
			{
				if (firfan[i] < store) {


					cout << rirfan[i] << "\t\t\t" << mirfan[i] << "\t\t\t" << firfan[i] << "\t\t\t" << cirfan[i] << "\t\t";
					if (firfan[i] > 86)
					{
						cout << girfan[0];
					}
					if (firfan[i] >= 73 && firfan[i] <= 85)
					{
						cout << girfan[1];
					}
					else if (firfan[i] >= 60 && firfan[i] <= 72)
					{
						cout << girfan[2];
					}
					else if (firfan[i] >= 50 && firfan[i] <= 60)
					{
						cout << girfan[3];
					}
					else if (firfan[i] < 50)
					{
						cout << girfan[4];
					}

					cout << endl;
				}
			}
			break;
		}
	}
		if (print==true) {
			// display results
			cout << "ROLL NUMBER" << "\t\tMID TERMS MARKS" << "\t\tFINAL MARKS" << "\t\tCLASS" << "\t\tGRADE" << endl;
			for (int i = 0; i < 10; i++)
			{

				cout << rirfan[i] << "\t\t\t" << mirfan[i] << "\t\t\t" << firfan[i] << "\t\t\t" << cirfan[i] << "\t\t";
				if (firfan[i] > 86)
				{
					cout << girfan[0];
				}
				if (firfan[i] >= 73 && firfan[i] <= 85)
				{
					cout << girfan[1];
				}
				else if (firfan[i] >= 60 && firfan[i] <= 72)
				{
					cout << girfan[2];
				}
				else if (firfan[i] >= 50 && firfan[i] <= 60)
				{
					cout << girfan[3];
				}
				else if (firfan[i] < 50)
				{
					cout << girfan[4];
				}

				cout << endl;
			}
		}
	} while (lab != 'e' || lab == 'E');
	return 0;
}
